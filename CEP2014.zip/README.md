CEP2014
=======

CEP Final Project 2014

use double line breaks for line breaks.

http://getuikit.com/


How to edit and test:

1) Install Github for Windows

2) Sign in

3) Create a clone of this project

4) On the tab on thr left rightclick this project name and click "open in explorer"

5) Do stuff normally(ie: editing, testing, yada yada.)

P.S. This project is due 10 Oct 2014